﻿#include "log.h"


HFLogger *Logger::GetLogger()
{
    return HFLogger::GetLogger();
}
