#include "idbmanager.h"

IDBManager::IDBManager()
{

}

IDBManager::~IDBManager()
{

}

